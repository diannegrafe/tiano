// script.js

document.addEventListener("DOMContentLoaded", () => {
  const chatButton = document.getElementById("chat-button");
  const chatContainer = document.getElementById("chat-container");
  const chatInput = document.getElementById("chat-input");
  const chatBody = document.getElementById("chat-body");

  chatButton.addEventListener("click", () => {
    chatContainer.classList.toggle("hidden");
  });

  chatInput.addEventListener("keypress", (event) => {
    if (event.key === "Enter" && chatInput.value.trim() !== "") {
      const userMessage = chatInput.value;
      appendMessage("You", userMessage);
      chatInput.value = "";
      setTimeout(
        () =>
          appendMessage(
            "Support",
            "Thank you for reaching out! We'll get back to you shortly."
          ),
        1000
      );
    }
  });

  function appendMessage(sender, message) {
    const messageElement = document.createElement("p");
    messageElement.textContent = `${sender}: ${message}`;
    messageElement.style.color = sender === "You" ? "#7f5539" : "#9c6644"; // Alternate text colors
    chatBody.appendChild(messageElement);
    chatBody.scrollTop = chatBody.scrollHeight;
  }
});
